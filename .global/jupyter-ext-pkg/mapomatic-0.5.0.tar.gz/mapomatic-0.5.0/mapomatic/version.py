# THIS FILE IS GENERATED FROM MAPOMATIC SETUP.PY
# pylint: disable=invalid-name, missing-module-docstring
short_version = '0.5.0'
version = '0.5.0'
release = True
