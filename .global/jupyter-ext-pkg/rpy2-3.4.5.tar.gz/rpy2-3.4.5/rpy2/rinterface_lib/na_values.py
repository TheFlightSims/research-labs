"""NA (Non-Available) values in R."""

NA_Character = None
NA_Integer = None
NA_Logical = None
NA_Real = None
NA_Complex = None
