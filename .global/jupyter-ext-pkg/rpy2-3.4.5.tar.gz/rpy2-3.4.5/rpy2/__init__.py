__version_vector__ = (3, 4, 5)

__version__ = '.'.join(str(x) for x in __version_vector__)
