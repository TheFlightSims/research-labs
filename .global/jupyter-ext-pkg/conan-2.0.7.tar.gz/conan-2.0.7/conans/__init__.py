CHECKSUM_DEPLOY = "checksum_deploy"  # Only when v2
REVISIONS = "revisions"  # Only when enabled in config, not by default look at server_launcher.py
OAUTH_TOKEN = "oauth_token"

__version__ = '2.0.7'
