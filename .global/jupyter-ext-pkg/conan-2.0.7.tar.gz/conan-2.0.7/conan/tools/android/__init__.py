from conan.tools.android.utils import android_abi
