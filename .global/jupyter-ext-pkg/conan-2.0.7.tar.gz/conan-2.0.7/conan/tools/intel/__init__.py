from conan.tools.intel.intel_cc import IntelCC
