# -*- coding: utf-8 -*-

import collections

Error = collections.namedtuple('Error', ('exception', 'traceback'))
