# RUN: echo %rec2 %%s %%%%s
