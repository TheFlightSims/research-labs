#!/usr/bin/env python

import sys


sys.stderr.write("a line on stderr\n")
sys.stderr.flush()
