# REQUIRES: woof, quack
# UNSUPPORTED: beta, gamma
# XFAIL: bar, baz
# RUN:
