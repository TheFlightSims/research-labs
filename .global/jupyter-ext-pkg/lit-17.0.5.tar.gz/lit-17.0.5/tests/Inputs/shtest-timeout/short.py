# RUN: %{python} %s
from __future__ import print_function

print("short program")
