#!/usr/bin/env python

import print_environment
import sys

print_environment.execute()
sys.exit(1)
