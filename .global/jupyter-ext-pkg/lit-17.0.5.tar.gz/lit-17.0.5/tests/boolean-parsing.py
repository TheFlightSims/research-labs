# Test the boolean expression parser
# used for REQUIRES and UNSUPPORTED and XFAIL

# RUN: %{python} -m lit.BooleanExpression
