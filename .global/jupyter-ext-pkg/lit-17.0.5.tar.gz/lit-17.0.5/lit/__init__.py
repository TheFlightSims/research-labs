"""'lit' Testing Tool"""

__author__ = "Daniel Dunbar"
__email__ = "daniel@minormatter.com"
__versioninfo__ = (17, 0, 5)
__version__ = ".".join(str(v) for v in __versioninfo__)

__all__ = []
