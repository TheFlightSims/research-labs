.. automodule:: cypari2.gen
    :members:
