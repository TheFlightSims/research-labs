.. automodule:: cypari2.closure
    :members:
