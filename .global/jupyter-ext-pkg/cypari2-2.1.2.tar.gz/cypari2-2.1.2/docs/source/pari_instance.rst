.. automodule:: cypari2.pari_instance
    :members:
