.. automodule:: cypari2.stack
    :members:
