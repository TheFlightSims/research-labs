.. automodule:: cypari2.handle_error
    :members:
