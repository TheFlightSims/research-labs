<!-- markdownlint-disable MD033 MD041 -->

<section-start>

```python
from IPython.display import display, Markdown
```

</section-start>

<section-start always class="check-me">

```python
display(Markdown('# Hello'))
```

</section-start>