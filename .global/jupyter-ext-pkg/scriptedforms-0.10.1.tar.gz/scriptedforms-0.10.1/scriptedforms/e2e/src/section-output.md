<!-- markdownlint-disable MD033 MD041 MD012 -->

<section-start>

```python
from IPython.display import display, Markdown
```

</section-start>

<section-start always>

```python
foo = ''
bar = 0
```

</section-start>

<variable-string class="write-in-me">foo</variable-string>
<variable-number>bar</variable-number>

<section-button class="click-me">

```python
bar += 1
```

</section-button>

<section-output class="check-me-running">

```python
print('foo: {}, bar: {}'.format(foo, bar))
```

</section-output>

