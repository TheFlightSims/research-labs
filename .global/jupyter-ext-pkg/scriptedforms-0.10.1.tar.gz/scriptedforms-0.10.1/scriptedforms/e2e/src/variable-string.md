<!-- markdownlint-disable MD033 MD041 MD012 -->

<section-start always>

```python
foo = ''
```

</section-start>

<section-live class="see-my-result">

<variable-string class="write-in-me-first">foo</variable-string>
<variable-string class="write-in-me-second">foo</variable-string>

```python
print(foo)
```

</section-live>

