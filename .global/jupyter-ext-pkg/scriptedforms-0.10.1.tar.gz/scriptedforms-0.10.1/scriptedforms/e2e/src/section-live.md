<!-- markdownlint-disable MD033 MD041 MD012 -->

<section-start>

```python
from IPython.display import display, Markdown
```

</section-start>

<section-start always>

```python
foo = 'bar'
```

</section-start>

<section-live class="check-me-running">

<variable-string class="write-in-me">foo</variable-string>

```python
print('{}'.format(foo))
```

</section-live>