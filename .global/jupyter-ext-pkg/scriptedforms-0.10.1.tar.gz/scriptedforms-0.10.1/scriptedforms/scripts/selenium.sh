#!/bin/bash
cd "$(dirname "$0")"/../e2e
yarn selenium
cd - 
