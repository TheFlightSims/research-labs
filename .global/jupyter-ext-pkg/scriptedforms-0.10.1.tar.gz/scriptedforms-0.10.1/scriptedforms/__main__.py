from .scriptedforms import main as _main

if __name__ == '__main__':
    _main()
