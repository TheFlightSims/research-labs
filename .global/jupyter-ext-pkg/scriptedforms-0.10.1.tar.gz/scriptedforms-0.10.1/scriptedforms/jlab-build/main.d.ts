import './public-path';
import './polyfills';
import './vendors/jupyterlab';
import './vendors/angular';
import './vendors/misc';
import 'hammerjs';
import { plugin } from './jupyterlab-extension/jupyterlab-plugin';
export default plugin;
