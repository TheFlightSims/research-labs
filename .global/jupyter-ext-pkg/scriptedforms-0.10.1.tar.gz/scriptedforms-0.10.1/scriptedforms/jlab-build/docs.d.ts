import './docs/style.css';
export declare function loadDocs(): void;
