import './app/style.css';
export declare function loadApp(): void;
