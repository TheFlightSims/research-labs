"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("./public-path");
// Polyfills
require("core-js/es6/reflect");
require("core-js/es7/reflect");
require("zone.js/dist/zone");
//# sourceMappingURL=polyfills.js.map