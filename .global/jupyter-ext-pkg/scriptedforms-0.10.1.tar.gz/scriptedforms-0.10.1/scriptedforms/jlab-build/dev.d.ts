import { ServiceManager } from '@jupyterlab/services';
export declare function loadDev(serviceManager?: ServiceManager): void;
