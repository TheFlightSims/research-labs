declare var __webpack_public_path__: any;
declare const CONFIG_DIV: HTMLElement;
