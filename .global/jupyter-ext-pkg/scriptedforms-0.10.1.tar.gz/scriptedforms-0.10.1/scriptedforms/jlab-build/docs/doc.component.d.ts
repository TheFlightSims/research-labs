export declare class DocComponent {
    constructor();
}
