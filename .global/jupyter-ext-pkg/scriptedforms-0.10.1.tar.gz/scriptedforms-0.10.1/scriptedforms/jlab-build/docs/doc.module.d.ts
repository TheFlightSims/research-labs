export declare class DocModule {
}
