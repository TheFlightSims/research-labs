import { ModuleWithProviders } from '@angular/core';
export declare const RoutingModule: ModuleWithProviders;
