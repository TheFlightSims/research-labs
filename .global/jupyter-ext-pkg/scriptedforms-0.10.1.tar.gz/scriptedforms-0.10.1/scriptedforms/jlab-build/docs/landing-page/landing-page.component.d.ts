import { ElementRef, AfterViewInit } from '@angular/core';
export declare class LandingPageComponent implements AfterViewInit {
    formWrapper: ElementRef;
    constructor();
    ngAfterViewInit(): void;
}
