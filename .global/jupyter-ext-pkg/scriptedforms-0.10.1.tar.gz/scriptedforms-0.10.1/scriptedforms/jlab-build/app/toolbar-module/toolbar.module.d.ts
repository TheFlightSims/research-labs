export declare class ToolbarModule {
}
