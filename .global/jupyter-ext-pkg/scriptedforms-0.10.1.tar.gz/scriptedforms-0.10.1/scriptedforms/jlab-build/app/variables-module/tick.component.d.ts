import { VariableBaseComponent } from './variable-base.component';
import { AfterViewInit } from '@angular/core';
export declare class TickComponent extends VariableBaseComponent implements AfterViewInit {
}
