import { VariableBaseComponent } from './variable-base.component';
import { AfterViewInit } from '@angular/core';
export declare class VariableParameterComponent extends VariableBaseComponent implements AfterViewInit {
    variableValue: any;
}
