export declare class VariablesModule {
}
