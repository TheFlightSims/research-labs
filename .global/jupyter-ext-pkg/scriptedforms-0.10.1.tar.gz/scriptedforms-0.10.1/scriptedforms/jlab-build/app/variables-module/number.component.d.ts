import { NumberBaseComponent } from './number-base.component';
import { AfterViewInit } from '@angular/core';
export declare class NumberComponent extends NumberBaseComponent implements AfterViewInit {
}
