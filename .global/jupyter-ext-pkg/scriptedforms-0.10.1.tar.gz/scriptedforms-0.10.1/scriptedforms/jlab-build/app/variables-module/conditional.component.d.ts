import { VariableBaseComponent } from './variable-base.component';
import { AfterViewInit } from '@angular/core';
export declare class ConditionalComponent extends VariableBaseComponent implements AfterViewInit {
}
