import { ErrorHandler } from '@angular/core';
export declare class AppErrorHandler extends ErrorHandler {
    handleError(error: any): void;
}
