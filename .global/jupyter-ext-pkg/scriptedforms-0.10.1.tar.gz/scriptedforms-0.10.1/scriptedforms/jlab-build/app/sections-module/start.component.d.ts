import { SectionBaseComponent } from './section-base.component';
export declare class StartComponent extends SectionBaseComponent {
    sectionType: string;
    always?: string;
}
