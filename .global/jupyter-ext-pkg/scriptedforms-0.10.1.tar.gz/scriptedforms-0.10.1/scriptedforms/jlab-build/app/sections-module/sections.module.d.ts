export declare class SectionsModule {
}
