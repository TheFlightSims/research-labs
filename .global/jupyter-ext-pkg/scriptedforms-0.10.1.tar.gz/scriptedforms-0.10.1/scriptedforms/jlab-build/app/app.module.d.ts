import { ApplicationRef } from '@angular/core';
export declare class AppModule {
    ngDoBootstrap(app: ApplicationRef): void;
}
