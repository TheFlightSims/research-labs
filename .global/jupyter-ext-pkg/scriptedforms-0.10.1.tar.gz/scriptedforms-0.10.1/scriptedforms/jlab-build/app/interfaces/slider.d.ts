export interface Slider {
    min: number;
    max: number;
    step: number;
    value: number;
}
