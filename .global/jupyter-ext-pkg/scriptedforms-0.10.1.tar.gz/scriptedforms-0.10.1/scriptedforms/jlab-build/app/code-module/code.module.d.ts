export declare class CodeModule {
}
