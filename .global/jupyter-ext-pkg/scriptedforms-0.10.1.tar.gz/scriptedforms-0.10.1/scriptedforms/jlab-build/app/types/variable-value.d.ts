import { PandasTable } from '../interfaces/pandas-table';
import { Slider } from '../interfaces/slider';
export declare type VariableValue = boolean | string | number | PandasTable | Slider | string[] | number[];
