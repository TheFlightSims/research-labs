export declare type FormStatus = 'initialising' | 'ready' | 'restarting';
