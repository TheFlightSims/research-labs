py CLI
======
.. automodule:: py
   :members:
