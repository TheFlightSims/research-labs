autoipython CLI
===============
.. automodule:: bin.autoipython
   :members:
   :undoc-members: False
