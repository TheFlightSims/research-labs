_flags module
=============
.. automodule:: pyflyby._flags
   :members:

   .. autofunction:: pyflyby._flags.CompilerFlags
