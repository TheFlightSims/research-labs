_idents module
==============
.. automodule:: pyflyby._idents
   :members:
   :exclude-members: _my_iskeyword